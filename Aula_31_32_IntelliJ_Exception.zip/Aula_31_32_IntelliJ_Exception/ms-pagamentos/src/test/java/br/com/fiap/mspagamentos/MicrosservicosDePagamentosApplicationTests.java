package br.com.fiap.mspagamentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicrosservicosDePagamentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
