package br.com.fiap.mspagamentos;

import br.com.fiap.mspagamentos.model.Pagamento;
import br.com.fiap.mspagamentos.repository.PagamentoRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Optional;

@DataJpaTest
public class PagamentoRepositoryTest {

    @Autowired
    private PagamentoRepository repository;

    //testing deletion
    @Test
    public void deleteShouldDeleteObjectWhenIdExists(){
        //arrange
        Long existingId = 1L;
        //act
        repository.deleteById((existingId));
        //assert
        Optional<Pagamento> result = repository.findById(existingId);
        //confirm deletion
        Assertions.assertFalse(result.isPresent());
    }
}
